Pixel art is not mine.
All systems/mechanics are.